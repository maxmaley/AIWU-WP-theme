import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';

function AppContent() {
  const { theme } = useTheme();
  
  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      theme === 'dark' 
        ? 'bg-[#1a1a1a] text-white' 
        : 'bg-gray-50 text-gray-900'
    }`}>
      <Header />
      <Hero />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}