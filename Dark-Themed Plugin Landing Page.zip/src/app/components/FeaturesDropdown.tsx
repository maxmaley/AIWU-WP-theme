import { ArrowRight } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

export function FeaturesDropdown() {
  const { theme } = useTheme();
  
  return (
    <div className={`absolute top-full left-1/2 -translate-x-1/2 mt-6 w-[900px] backdrop-blur-xl border rounded-3xl shadow-2xl p-8 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 ${
      theme === 'dark'
        ? 'bg-[#1a1a1a]/95 border-white/10'
        : 'bg-white/95 border-gray-200'
    }`}>
      <div className="grid grid-cols-2 gap-8">
        {/* Left Side - Workflow Builder */}
        <div className={`border-r pr-8 ${
          theme === 'dark' ? 'border-white/10' : 'border-gray-200'
        }`}>
          <h3 className={`text-xl mb-3 ${
            theme === 'dark' ? 'text-white' : 'text-gray-900'
          }`}>Workflow Builder</h3>
          <p className={`text-sm leading-relaxed mb-6 ${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
          }`}>
            Custom automation solution with Drag & Drop interface and dozens of integrations to automate anything you need.
          </p>
          <div className="flex flex-col gap-2">
            <a href="#learn-more" className="text-[#FF6B3B] hover:text-[#FF7B4B] text-sm flex items-center gap-1 transition-colors">
              Learn more <ArrowRight size={14} />
            </a>
            <a href="#templates" className="text-[#FF6B3B] hover:text-[#FF7B4B] text-sm flex items-center gap-1 transition-colors">
              Templates <ArrowRight size={14} />
            </a>
            <a href="#integrations" className="text-[#FF6B3B] hover:text-[#FF7B4B] text-sm flex items-center gap-1 transition-colors">
              Integrations <ArrowRight size={14} />
            </a>
          </div>
        </div>

        {/* Right Side - Ready to use apps */}
        <div className="pl-8">
          <h3 className={`text-xl mb-3 ${
            theme === 'dark' ? 'text-white' : 'text-gray-900'
          }`}>Ready to use apps</h3>
          <p className={`text-sm leading-relaxed mb-6 ${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
          }`}>
            Standalone AI features that work instantly. No workflow building required—just enable and start using.
          </p>
          
          <div className="grid grid-cols-2 gap-3">
            {/* AI ChatBot */}
            <a href="#chatbot" className={`group/item p-3 rounded-xl transition-colors ${
              theme === 'dark' ? 'hover:bg-white/5' : 'hover:bg-gray-100'
            }`}>
              <div className={`text-sm mb-1 ${
                theme === 'dark' ? 'text-white' : 'text-gray-900'
              }`}>AI ChatBot</div>
              <div className={`text-xs ${
                theme === 'dark' ? 'text-gray-500' : 'text-gray-500'
              }`}>24/7 customer support</div>
            </a>

            {/* AI Forms Builder */}
            <a href="#forms" className={`group/item p-3 rounded-xl transition-colors ${
              theme === 'dark' ? 'hover:bg-white/5' : 'hover:bg-gray-100'
            }`}>
              <div className={`text-sm mb-1 ${
                theme === 'dark' ? 'text-white' : 'text-gray-900'
              }`}>AI Forms Builder</div>
              <div className={`text-xs ${
                theme === 'dark' ? 'text-gray-500' : 'text-gray-500'
              }`}>Smart adaptive forms</div>
            </a>

            {/* Bulk Post Generator */}
            <a href="#bulk" className={`group/item p-3 rounded-xl transition-colors ${
              theme === 'dark' ? 'hover:bg-white/5' : 'hover:bg-gray-100'
            }`}>
              <div className={`text-sm mb-1 ${
                theme === 'dark' ? 'text-white' : 'text-gray-900'
              }`}>Bulk Post Generator</div>
              <div className={`text-xs ${
                theme === 'dark' ? 'text-gray-500' : 'text-gray-500'
              }`}>Multiple posts at once</div>
            </a>

            {/* Autoblogging */}
            <a href="#autoblog" className={`group/item p-3 rounded-xl transition-colors ${
              theme === 'dark' ? 'hover:bg-white/5' : 'hover:bg-gray-100'
            }`}>
              <div className={`text-sm mb-1 ${
                theme === 'dark' ? 'text-white' : 'text-gray-900'
              }`}>Autoblogging</div>
              <div className={`text-xs ${
                theme === 'dark' ? 'text-gray-500' : 'text-gray-500'
              }`}>Automated publishing</div>
            </a>

            {/* WooCommerce Generator */}
            <a href="#woo" className={`group/item p-3 rounded-xl transition-colors ${
              theme === 'dark' ? 'hover:bg-white/5' : 'hover:bg-gray-100'
            }`}>
              <div className={`text-sm mb-1 ${
                theme === 'dark' ? 'text-white' : 'text-gray-900'
              }`}>WooCommerce Generator</div>
              <div className={`text-xs ${
                theme === 'dark' ? 'text-gray-500' : 'text-gray-500'
              }`}>Create products with AI</div>
            </a>

            {/* Magic Text Enhancer */}
            <a href="#enhancer" className={`group/item p-3 rounded-xl transition-colors ${
              theme === 'dark' ? 'hover:bg-white/5' : 'hover:bg-gray-100'
            }`}>
              <div className={`text-sm mb-1 ${
                theme === 'dark' ? 'text-white' : 'text-gray-900'
              }`}>Magic Text Enhancer</div>
              <div className={`text-xs ${
                theme === 'dark' ? 'text-gray-500' : 'text-gray-500'
              }`}>Improve text instantly</div>
            </a>

            {/* MCP Integration */}
            <a href="#mcp" className={`group/item p-3 rounded-xl transition-colors ${
              theme === 'dark' ? 'hover:bg-white/5' : 'hover:bg-gray-100'
            }`}>
              <div className={`text-sm mb-1 ${
                theme === 'dark' ? 'text-white' : 'text-gray-900'
              }`}>MCP Integration</div>
              <div className={`text-xs ${
                theme === 'dark' ? 'text-gray-500' : 'text-gray-500'
              }`}>External services</div>
            </a>

            {/* AI Training */}
            <a href="#training" className={`group/item p-3 rounded-xl transition-colors ${
              theme === 'dark' ? 'hover:bg-white/5' : 'hover:bg-gray-100'
            }`}>
              <div className={`text-sm mb-1 ${
                theme === 'dark' ? 'text-white' : 'text-gray-900'
              }`}>AI Training</div>
              <div className={`text-xs ${
                theme === 'dark' ? 'text-gray-500' : 'text-gray-500'
              }`}>Train on your content</div>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}