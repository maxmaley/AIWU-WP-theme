import { Moon, Sun } from 'lucide-react';
import { useState } from 'react';
import { FeaturesDropdown } from './FeaturesDropdown';
import { ResourcesDropdown } from './ResourcesDropdown';
import { useTheme } from '../contexts/ThemeContext';
import Group from '../../imports/Group1000003479';

export function Header() {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="fixed top-6 left-0 right-0 z-50 px-6">
      <div className={`max-w-7xl mx-auto px-6 h-16 flex items-center justify-between backdrop-blur-xl border rounded-full shadow-lg transition-colors duration-300 ${
        theme === 'dark'
          ? 'bg-[#1a1a1a]/60 border-white/10'
          : 'bg-white/60 border-gray-200'
      }`}>
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="h-6">
            <Group />
          </div>
        </div>

        {/* Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <div className="relative group">
            <a href="#features" className={`transition-colors text-sm ${
              theme === 'dark' 
                ? 'text-gray-300 hover:text-white' 
                : 'text-gray-600 hover:text-gray-900'
            }`}>
              Features
            </a>
            <FeaturesDropdown />
          </div>
          <a href="#pricing" className={`transition-colors text-sm ${
            theme === 'dark' 
              ? 'text-gray-300 hover:text-white' 
              : 'text-gray-600 hover:text-gray-900'
          }`}>
            Pricing
          </a>
          <div className="relative group">
            <a href="#resources" className={`transition-colors text-sm ${
              theme === 'dark' 
                ? 'text-gray-300 hover:text-white' 
                : 'text-gray-600 hover:text-gray-900'
            }`}>
              Resources
            </a>
            <ResourcesDropdown />
          </div>
          <a href="#contact" className={`transition-colors text-sm ${
            theme === 'dark' 
              ? 'text-gray-300 hover:text-white' 
              : 'text-gray-600 hover:text-gray-900'
          }`}>
            Contact
          </a>
        </nav>

        {/* Right side actions */}
        <div className="flex items-center gap-4">
          <button
            onClick={toggleTheme}
            className={`p-2 transition-colors ${
              theme === 'dark'
                ? 'text-gray-300 hover:text-white'
                : 'text-gray-600 hover:text-gray-900'
            }`}
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <a
            href="#login"
            className={`transition-colors hidden sm:block text-sm ${
              theme === 'dark'
                ? 'text-gray-300 hover:text-white'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Login
          </a>
          <a
            href="#get-started"
            className="px-5 py-2 bg-[#FF6B3B] hover:bg-[#FF7B4B] text-white rounded-full transition-colors text-sm"
          >
            Get Started
          </a>
        </div>
      </div>
    </header>
  );
}