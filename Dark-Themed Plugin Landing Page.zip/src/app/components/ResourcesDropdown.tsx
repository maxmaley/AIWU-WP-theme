import { useTheme } from '../contexts/ThemeContext';

export function ResourcesDropdown() {
  const { theme } = useTheme();
  
  return (
    <div className={`absolute top-full left-1/2 -translate-x-1/2 mt-6 w-[400px] backdrop-blur-xl border rounded-2xl shadow-2xl p-6 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 ${
      theme === 'dark'
        ? 'bg-[#1a1a1a]/95 border-white/10'
        : 'bg-white/95 border-gray-200'
    }`}>
      <div className="flex flex-col gap-1">
        <a href="#about" className={`px-4 py-3 rounded-lg transition-colors text-sm ${
          theme === 'dark'
            ? 'hover:bg-white/5 text-white'
            : 'hover:bg-gray-100 text-gray-900'
        }`}>
          About
        </a>
        <a href="#community" className={`px-4 py-3 rounded-lg transition-colors text-sm ${
          theme === 'dark'
            ? 'hover:bg-white/5 text-white'
            : 'hover:bg-gray-100 text-gray-900'
        }`}>
          Community
        </a>
        <a href="#knowledge-base" className={`px-4 py-3 rounded-lg transition-colors text-sm ${
          theme === 'dark'
            ? 'hover:bg-white/5 text-white'
            : 'hover:bg-gray-100 text-gray-900'
        }`}>
          Knowledge Base
        </a>
        <a href="#blog" className={`px-4 py-3 rounded-lg transition-colors text-sm ${
          theme === 'dark'
            ? 'hover:bg-white/5 text-white'
            : 'hover:bg-gray-100 text-gray-900'
        }`}>
          Blog
        </a>
        <a href="#roadmap" className={`px-4 py-3 rounded-lg transition-colors text-sm ${
          theme === 'dark'
            ? 'hover:bg-white/5 text-white'
            : 'hover:bg-gray-100 text-gray-900'
        }`}>
          Roadmap
        </a>
        <a href="#api" className={`px-4 py-3 rounded-lg transition-colors text-sm ${
          theme === 'dark'
            ? 'hover:bg-white/5 text-white'
            : 'hover:bg-gray-100 text-gray-900'
        }`}>
          API
        </a>
        <a href="#ai-models" className={`px-4 py-3 rounded-lg transition-colors text-sm ${
          theme === 'dark'
            ? 'hover:bg-white/5 text-white'
            : 'hover:bg-gray-100 text-gray-900'
        }`}>
          Supported AI Models
        </a>
      </div>
    </div>
  );
}