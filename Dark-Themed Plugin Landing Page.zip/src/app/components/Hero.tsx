import { ArrowRight, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { useTheme } from '../contexts/ThemeContext';

export function Hero() {
  const { theme } = useTheme();
  
  return (
    <section className="relative min-h-screen flex items-center justify-center px-6 pt-24 overflow-hidden">
      {/* Animated Background Grid */}
      <div className={`absolute inset-0 bg-[linear-gradient(rgba(255,107,59,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,107,59,0.03)_1px,transparent_1px)] bg-[size:64px_64px] transition-opacity duration-300 ${
        theme === 'dark'
          ? '[mask-image:radial-gradient(ellipse_80%_50%_at_50%_50%,black,transparent)]'
          : '[mask-image:radial-gradient(ellipse_80%_50%_at_50%_50%,black,transparent)] opacity-50'
      }`}></div>

      <div className="relative max-w-5xl mx-auto text-center z-10">
        {/* Badge with Animation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className={`inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-[#FF6B3B]/10 to-[#FF6B3B]/5 border border-[#FF6B3B]/20 mb-8 backdrop-blur-sm ${
            theme === 'dark' ? '' : 'bg-opacity-80'
          }`}
        >
          <Sparkles size={14} className="text-[#FF6B3B]" />
          <span className={`text-sm ${
            theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
          }`}>
            Trusted by 1,000+ WordPress sites
          </span>
        </motion.div>

        {/* Main Headline with Gradient */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-6 leading-[1.1]"
        >
          <div className={`text-5xl md:text-6xl lg:text-7xl mb-2 tracking-tight ${
            theme === 'dark' ? 'text-white' : 'text-gray-900'
          }`}>
            WordPress automations
          </div>
          <div className="text-5xl md:text-6xl lg:text-7xl tracking-tight bg-gradient-to-r from-[#FF6B3B] via-[#FF8A6B] to-[#FFA98B] bg-clip-text text-transparent">
            you'll actually use
          </div>
        </motion.h1>

        {/* Subheadline */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className={`text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed ${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
          }`}
        >
          Connect AI to your WordPress and build workflows from customer support to content—without code.
        </motion.p>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <a
            href="#get-started"
            className="group relative inline-flex items-center gap-2 px-7 py-3.5 bg-gradient-to-r from-[#FF6B3B] to-[#FF8A6B] text-white rounded-full transition-all hover:scale-105 shadow-[0_0_40px_rgba(255,107,59,0.3)] hover:shadow-[0_0_60px_rgba(255,107,59,0.5)]"
          >
            <span>Get Started Free</span>
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}