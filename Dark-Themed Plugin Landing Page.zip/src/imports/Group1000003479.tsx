import svgPaths from "./svg-76q61kh7rt";

export default function Group() {
  return (
    <div className="relative size-full">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 125 43">
        <g id="Group 1000003479">
          <path d={svgPaths.pd2d5b00} fill="url(#paint0_linear_3_76)" id="Vector" />
          <path d={svgPaths.p2bce4680} fill="url(#paint1_linear_3_76)" id="Vector_2" />
          <path d={svgPaths.p338ba500} fill="var(--fill-0, white)" id="Vector_3" />
        </g>
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_3_76" x1="31.4815" x2="31.4815" y1="0" y2="50.8182">
            <stop stopColor="#FF6B3B" />
            <stop offset="1" stopColor="#FF6B3B" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_3_76" x1="10.1852" x2="10.1852" y1="19.5455" y2="52.7727">
            <stop stopColor="#007C91" />
            <stop offset="1" stopColor="#007C91" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}