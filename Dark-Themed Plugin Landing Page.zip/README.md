
  # Dark-Themed Plugin Landing Page

  This is a code bundle for Dark-Themed Plugin Landing Page. The original project is available at https://www.figma.com/design/T166OF4Z2J8jRxR0wLmYqw/Dark-Themed-Plugin-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  